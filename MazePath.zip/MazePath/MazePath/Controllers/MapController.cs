﻿using MazePath.Models;
using MazePath.Service;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MazePath.Controllers
{
    public class MapController : ApiController
    {
        [HttpPost]
        public MapResult SolveMaze(MapRequest mapRequest)
        {
            MapService mapService = new MapService();

            return mapService.SolveMaze(mapRequest.MazeString);
        }

        //// GET api/values        
        //[HttpGet]
        //public IEnumerable<string> AllValues()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        //public HttpResponseMessage Get()
        //{
        //    HttpResponseMessage message = Request.CreateResponse<string[]>(HttpStatusCode.OK, new string[] { "value1", "value2" });

        //    return message;
        //}


    }
}
