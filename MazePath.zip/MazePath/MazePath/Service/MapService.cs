﻿using MazePath.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace MazePath.Service
{
    public class MapService
    {
        const string START_POINT = "A";
        const string END_POINT = "B";
        const string OPEN_ROAD = ".";
        const string CLOSE_ROAD = "#";
        const string SOLUTION_PATH = "@";

        public MapResult SolveMaze(string mazeString)
        {
            int startPointRow;
            int startPointColumn;
            int steps = 0;

            string[,] maze = GetMazeArray(mazeString, out startPointRow, out startPointColumn);

            //if (startPointRow < 0)
            //{
            //    throw new Exception("No Start Point");
            //}

            //if (noEndPoint) //Not implemented
            //{
            //    throw new Exception("No Start Point");
            //}

            string[,] trackMaze = new string[maze.GetLength(0), maze.GetLength(1)];
            Travese(maze, startPointRow, startPointColumn, trackMaze, ref steps);

            //if (steps == 0)
            //{
            //    throw new Exception("No Path between start and end point");
            //}

            //To test in console application
            //Console.WriteLine("Total Steps: " + steps);
            //Console.WriteLine(GetMazeString(maze));

            return new MapResult()
            {
                Steps = steps,
                Solution = GetMazeString(maze)

            };
        }

        /// <summary>
        /// Converts input string to array
        /// </summary>
        /// <param name="mazeString">Input maze string</param>
        /// <param name="startPointRow">Starting point row index</param>
        /// <param name="startPointColumn">Starting point column index</param>
        /// <returns>Maze array</returns>
        private string[,] GetMazeArray(string mazeString, out int startPointRow, out int startPointColumn)
        {
            string[,] mazeArr = null;
            startPointRow = -1;
            startPointColumn = -1;

            if (!string.IsNullOrEmpty(mazeString))
            {
                string[] rows = null;

                if (mazeString.Contains("\n"))
                {
                    rows = mazeString.Split(new[] { "\n" }, StringSplitOptions.None);
                }
                else
                {
                    rows = mazeString.Split(new[] { " " }, StringSplitOptions.None);
                }

                if (rows.Length > 0)
                {
                    int rowsCount = rows.Length;
                    int colCount = rows[0].ToCharArray().Length;

                    mazeArr = new string[rowsCount, colCount];

                    int rowInc = 0;
                    foreach (var row in rows)
                    {
                        var rowChars = row.ToCharArray();

                        for (int colInc = 0; colInc < rowChars.Length; colInc++)
                        {
                            var colValue = rowChars[colInc].ToString();

                            if (startPointRow < 0 && colValue == START_POINT)
                            {
                                startPointRow = rowInc;
                                startPointColumn = colInc;
                            }

                            mazeArr[rowInc, colInc] = colValue;
                        }

                        rowInc++;
                    }
                }
            }

            return mazeArr;
        }

        /// <summary>
        /// Validates column based on provided index values
        /// </summary>
        /// <param name="maze">Input maze</param>
        /// <param name="row">Next column row index</param>
        /// <param name="column">Next column column index</param>
        /// <returns> Can move to next element</returns>
        private bool CanMove(string[,] maze, int row, int column)
        {
            return (row >= 0 && row < maze.GetLength(0) - 1 && column >= 0 && column < maze.GetLength(1) - 1 && (maze[row, column] == OPEN_ROAD || maze[row, column] == END_POINT));
        }

        /// <summary>
        /// Recurcive method to find maze path
        /// </summary>
        /// <param name="maze">Input maze</param>
        /// <param name="row">Starting point row index</param>
        /// <param name="column">Starting point column index</param>
        /// <param name="trackMaze">Maze to trak visited elements</param>
        /// <param name="steps">No of step required from start point to end point</param>
        /// <returns>Return move to next or not</returns>
        private bool Travese(string[,] maze, int row, int column, string[,] trackMaze, ref int steps)
        {
            if (maze[row, column] == END_POINT)
            {
                steps++;
                return true;
            }

            if (trackMaze[row, column] != "T")
            {
                trackMaze[row, column] = "T";

                ////Right
                if (CanMove(maze, row, column + 1) && Travese(maze, row, column + 1, trackMaze, ref steps))
                {
                    if (maze[row, column + 1] != END_POINT)
                    {
                        maze[row, column + 1] = SOLUTION_PATH;
                        steps++;
                    }

                    return true;
                }

                //Bottom
                if (CanMove(maze, row + 1, column) && Travese(maze, row + 1, column, trackMaze, ref steps))
                {
                    if (maze[row + 1, column] != END_POINT)
                    {
                        maze[row + 1, column] = SOLUTION_PATH;
                        steps++;
                    }

                    return true;
                }

                ////Top
                if (CanMove(maze, row - 1, column) && Travese(maze, row - 1, column, trackMaze, ref steps))
                {
                    if (maze[row - 1, column] != END_POINT)
                    {
                        maze[row - 1, column] = SOLUTION_PATH;
                        steps++;
                    }

                    return true;
                }

                //Left
                if (CanMove(maze, row, column - 1) && Travese(maze, row, column - 1, trackMaze, ref steps))
                {
                    if (maze[row, column - 1] != END_POINT)
                    {
                        maze[row, column - 1] = SOLUTION_PATH;
                        steps++;
                    }

                    return true;
                }
            }

            return false;
        }       

        private string GetMazeString(string[,] maze)
        {
            StringBuilder mazeOutput = new StringBuilder();

            for (int rowInc = 0; rowInc < maze.GetLength(0); rowInc++)
            {
                for (int colInc = 0; colInc < maze.GetLength(1); colInc++)
                {
                    mazeOutput.Append(maze[rowInc, colInc]);
                }

                mazeOutput.Append("\n");
            }

            return mazeOutput.ToString();
        }

        //private List<string> GetMazeResult(string[,] maze)
        //{
        //    List<string> mazeResult = new List<string>();

        //    for (int rowInc = 0; rowInc < maze.GetLength(0); rowInc++)
        //    {
        //        StringBuilder mazeOutput = new StringBuilder();

        //        for (int colInc = 0; colInc < maze.GetLength(1); colInc++)
        //        {
        //            mazeOutput.Append(maze[rowInc, colInc]);
        //        }

        //        mazeResult.Add(mazeOutput.ToString());
        //    }

        //    return mazeResult;
        //}

        //private int GetStepsCount(string[,] maze)
        //{
        //    int steps = 0;

        //    for (int rowInc = 0; rowInc < maze.GetLength(0); rowInc++)
        //    {
        //        for (int colInc = 0; colInc < maze.GetLength(1); colInc++)
        //        {
        //            if (maze[rowInc, colInc] == SOLUTION_PATH)
        //            {
        //                steps++;
        //            }
        //        }
        //    }

        //    return steps;
        //}
    }
}